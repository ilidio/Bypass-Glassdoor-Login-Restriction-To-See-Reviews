/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
    document.getElementById("ContentWallHardsell").innerHTML = "ContentWallHardsell";
    let r="html,body{overflow:auto !important;}";
    let s=document.createElement("style");
    s.type="text/css";
    s.appendChild(document.createTextNode(r));
    document.body.appendChild(s);
    void 0;
/******/ })()
;
//# sourceMappingURL=content.js.map